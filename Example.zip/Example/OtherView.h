/*
  WiseGui Library's usage example

  file: OtherView.h

  Copyright (c) 2013, Alessandro De Santis
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the author nor the names of its contributors may 
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

// AUTO GENERATED CODE
#ifndef __OtherView_
#define __OtherView_

#include "ids.h"
#include "bgeres.h"
#include "wisegui.h"

class OtherView : public View
{
public:
    OtherView(ControlListener *cl) : View(cl)
    {
		SetSize(480, 360);
		SetImageId(IMG_OtherView);

		Button *ctl_kButton1 = new Button();
		ctl_kButton1->SetSize(72, 30);
		ctl_kButton1->SetLocation(380, 316);
		ctl_kButton1->SetParamIndex(kButton1);
		ctl_kButton1->SetImageId(IMG_Button2);
		Add(ctl_kButton1);

		VSlider *ctl_kVSlider1 = new VSlider();
		ctl_kVSlider1->SetSize(22, 100);
		ctl_kVSlider1->SetLocation(91, 78);
		ctl_kVSlider1->SetParamIndex(kVSlider1);
		ctl_kVSlider1->SetImageId(IMG_VSlider);
		ctl_kVSlider1->SetMin(-1);
		ctl_kVSlider1->SetMax(1);
		ctl_kVSlider1->SetLength(84);
		ctl_kVSlider1->SetOffset(8);
		ctl_kVSlider1->SetHandleId(IMG_VSliderHandle);
		Add(ctl_kVSlider1);

		VSlider *ctl_kVSlider2 = new VSlider();
		ctl_kVSlider2->SetSize(22, 100);
		ctl_kVSlider2->SetLocation(145, 78);
		ctl_kVSlider2->SetParamIndex(kVSlider2);
		ctl_kVSlider2->SetImageId(IMG_VSlider);
		ctl_kVSlider2->SetMin(-0.5);
		ctl_kVSlider2->SetMax(0.5);
		ctl_kVSlider2->SetLength(84);
		ctl_kVSlider2->SetOffset(8);
		ctl_kVSlider2->SetHandleId(IMG_VSliderHandle);
		Add(ctl_kVSlider2);

		VSlider *ctl_kVSlider3 = new VSlider();
		ctl_kVSlider3->SetSize(22, 100);
		ctl_kVSlider3->SetLocation(199, 78);
		ctl_kVSlider3->SetParamIndex(kVSlider3);
		ctl_kVSlider3->SetImageId(IMG_VSlider);
		ctl_kVSlider3->SetMin(-10);
		ctl_kVSlider3->SetMax(10);
		ctl_kVSlider3->SetLength(84);
		ctl_kVSlider3->SetOffset(8);
		ctl_kVSlider3->SetHandleId(IMG_VSliderHandle);
		Add(ctl_kVSlider3);

		Label *ctl_kLabel1 = new Label();
		ctl_kLabel1->SetSize(48, 22);
		ctl_kLabel1->SetLocation(78, 45);
		ctl_kLabel1->SetParamIndex(kLabel1);
		ctl_kLabel1->SetImageId(IMG_Label);
		ctl_kLabel1->SetAlignment(1);
		ctl_kLabel1->SetFontFamily("Verdana");
		ctl_kLabel1->SetFontSize(10);
		ctl_kLabel1->SetFontColor(255, 186, 217, 239);
		Add(ctl_kLabel1);

		Label *ctl_kLabel2 = new Label();
		ctl_kLabel2->SetSize(48, 22);
		ctl_kLabel2->SetLocation(132, 45);
		ctl_kLabel2->SetParamIndex(kLabel2);
		ctl_kLabel2->SetImageId(IMG_Label);
		ctl_kLabel2->SetAlignment(1);
		ctl_kLabel2->SetFontFamily("Verdana");
		ctl_kLabel2->SetFontSize(10);
		ctl_kLabel2->SetFontColor(255, 186, 217, 239);
		Add(ctl_kLabel2);

		Label *ctl_kLabel3 = new Label();
		ctl_kLabel3->SetSize(48, 22);
		ctl_kLabel3->SetLocation(186, 45);
		ctl_kLabel3->SetParamIndex(kLabel3);
		ctl_kLabel3->SetImageId(IMG_Label);
		ctl_kLabel3->SetAlignment(1);
		ctl_kLabel3->SetFontFamily("Verdana");
		ctl_kLabel3->SetFontSize(10);
		ctl_kLabel3->SetFontColor(255, 186, 217, 239);
		Add(ctl_kLabel3);

		Knob *ctl_kKnob2 = new Knob();
		ctl_kKnob2->SetSize(32, 32);
		ctl_kKnob2->SetLocation(313, 92);
		ctl_kKnob2->SetParamIndex(kKnob2);
		ctl_kKnob2->SetImageId(IMG_Knob);
		ctl_kKnob2->SetMin(-0.5);
		ctl_kKnob2->SetMax(0.5);
		ctl_kKnob2->SetFrames(36);
		Add(ctl_kKnob2);

		Knob *ctl_kKnob3 = new Knob();
		ctl_kKnob3->SetSize(32, 32);
		ctl_kKnob3->SetLocation(313, 135);
		ctl_kKnob3->SetParamIndex(kKnob3);
		ctl_kKnob3->SetImageId(IMG_Knob);
		ctl_kKnob3->SetMin(-10);
		ctl_kKnob3->SetMax(10);
		ctl_kKnob3->SetFrames(36);
		Add(ctl_kKnob3);

		Label *ctl_kLabel4 = new Label();
		ctl_kLabel4->SetSize(48, 22);
		ctl_kLabel4->SetLocation(366, 53);
		ctl_kLabel4->SetParamIndex(kLabel4);
		ctl_kLabel4->SetImageId(IMG_Label);
		ctl_kLabel4->SetAlignment(1);
		ctl_kLabel4->SetFontFamily("Verdana");
		ctl_kLabel4->SetFontSize(10);
		ctl_kLabel4->SetFontColor(255, 186, 217, 239);
		Add(ctl_kLabel4);

		Label *ctl_kLabel5 = new Label();
		ctl_kLabel5->SetSize(48, 22);
		ctl_kLabel5->SetLocation(366, 97);
		ctl_kLabel5->SetParamIndex(kLabel5);
		ctl_kLabel5->SetImageId(IMG_Label);
		ctl_kLabel5->SetAlignment(1);
		ctl_kLabel5->SetFontFamily("Verdana");
		ctl_kLabel5->SetFontSize(10);
		ctl_kLabel5->SetFontColor(255, 186, 217, 239);
		Add(ctl_kLabel5);

		Label *ctl_kLabel6 = new Label();
		ctl_kLabel6->SetSize(48, 22);
		ctl_kLabel6->SetLocation(366, 140);
		ctl_kLabel6->SetParamIndex(kLabel6);
		ctl_kLabel6->SetImageId(IMG_Label);
		ctl_kLabel6->SetAlignment(1);
		ctl_kLabel6->SetFontFamily("Verdana");
		ctl_kLabel6->SetFontSize(10);
		ctl_kLabel6->SetFontColor(255, 186, 217, 239);
		Add(ctl_kLabel6);

		Knob *ctl_kKnob1 = new Knob();
		ctl_kKnob1->SetSize(32, 32);
		ctl_kKnob1->SetLocation(313, 48);
		ctl_kKnob1->SetParamIndex(kKnob1);
		ctl_kKnob1->SetImageId(IMG_Knob);
		ctl_kKnob1->SetMin(-1);
		ctl_kKnob1->SetMax(1);
		ctl_kKnob1->SetFrames(36);
		Add(ctl_kKnob1);


    }    
	virtual void OnLoad();
	virtual void OnUpdate(int index, double value);
};
#endif

