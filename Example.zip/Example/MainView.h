/*
  WiseGui Library's usage example

  file: MainView.h

  Copyright (c) 2013, Alessandro De Santis
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the author nor the names of its contributors may 
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

// AUTO GENERATED CODE
#ifndef __MainView_
#define __MainView_

#include "ids.h"
#include "bgeres.h"
#include "wisegui.h"

class MainView : public View
{
public:
    MainView(ControlListener *cl) : View(cl)
    {
		SetSize(480, 360);
		SetImageId(IMG_MainView);

		Knob *ctl_kKnob = new Knob();
		ctl_kKnob->SetSize(32, 32);
		ctl_kKnob->SetLocation(393, 205);
		ctl_kKnob->SetParamIndex(kKnob);
		ctl_kKnob->SetImageId(IMG_Knob);
		ctl_kKnob->SetMin(-50);
		ctl_kKnob->SetMax(50);
		ctl_kKnob->SetFrames(36);
		Add(ctl_kKnob);

		VSwitch *ctl_kVSwitch = new VSwitch();
		ctl_kVSwitch->SetSize(44, 60);
		ctl_kVSwitch->SetLocation(77, 132);
		ctl_kVSwitch->SetParamIndex(kVSwitch);
		ctl_kVSwitch->SetImageId(IMG_VSwitch);
		ctl_kVSwitch->SetMin(0);
		ctl_kVSwitch->SetMax(2);
		ctl_kVSwitch->SetOptionsCount(3);
		Add(ctl_kVSwitch);

		VSlider *ctl_kVSlider = new VSlider();
		ctl_kVSlider->SetSize(22, 100);
		ctl_kVSlider->SetLocation(224, 232);
		ctl_kVSlider->SetParamIndex(kVSlider);
		ctl_kVSlider->SetImageId(IMG_VSlider);
		ctl_kVSlider->SetMin(-25);
		ctl_kVSlider->SetMax(25);
		ctl_kVSlider->SetLength(84);
		ctl_kVSlider->SetOffset(8);
		ctl_kVSlider->SetHandleId(IMG_VSliderHandle);
		Add(ctl_kVSlider);

		Checkbox *ctl_kCheckbox = new Checkbox();
		ctl_kCheckbox->SetSize(56, 16);
		ctl_kCheckbox->SetLocation(209, 146);
		ctl_kCheckbox->SetParamIndex(kCheckbox);
		ctl_kCheckbox->SetImageId(IMG_Led);
		Add(ctl_kCheckbox);

		DropDownList *ctl_kDropdownlist = new DropDownList();
		ctl_kDropdownlist->SetSize(100, 20);
		ctl_kDropdownlist->SetLocation(352, 101);
		ctl_kDropdownlist->SetParamIndex(kDropdownlist);
		ctl_kDropdownlist->SetImageId(IMG_DDList);
		ctl_kDropdownlist->SetFontFamily("Verdana");
		ctl_kDropdownlist->SetFontSize(10);
		ctl_kDropdownlist->SetFontColor(255, 186, 217, 239);
		char *ctl_kDropdownlist_items[] = {"Osc 1", "Osc 2", "Osc 3", "Osc 4", "Osc 5", "Osc 6", "Osc 7", "Osc 8"};
		ctl_kDropdownlist->SetItems(ctl_kDropdownlist_items, 8);
		Add(ctl_kDropdownlist);

		HSlider *ctl_kHSlider = new HSlider();
		ctl_kHSlider->SetSize(100, 22);
		ctl_kHSlider->SetLocation(47, 240);
		ctl_kHSlider->SetParamIndex(kHSlider);
		ctl_kHSlider->SetImageId(IMG_HSlider);
		ctl_kHSlider->SetMin(0);
		ctl_kHSlider->SetMax(50);
		ctl_kHSlider->SetLength(84);
		ctl_kHSlider->SetOffset(8);
		ctl_kHSlider->SetHandleId(IMG_HSliderHandle);
		Add(ctl_kHSlider);

		Button *ctl_kButton = new Button();
		ctl_kButton->SetSize(72, 30);
		ctl_kButton->SetLocation(380, 316);
		ctl_kButton->SetParamIndex(kButton);
		ctl_kButton->SetImageId(IMG_Button);
		Add(ctl_kButton);

		Label *ctl_kLabel = new Label();
		ctl_kLabel->SetSize(48, 22);
		ctl_kLabel->SetLocation(230, 55);
		ctl_kLabel->SetParamIndex(kLabel);
		ctl_kLabel->SetImageId(IMG_Label);
		ctl_kLabel->SetAlignment(1);
		ctl_kLabel->SetFontFamily("Verdana");
		ctl_kLabel->SetFontSize(10);
		ctl_kLabel->SetFontColor(255, 186, 217, 239);
		Add(ctl_kLabel);

		StateButton *ctl_kStatebutton = new StateButton();
		ctl_kStatebutton->SetSize(56, 24);
		ctl_kStatebutton->SetLocation(70, 318);
		ctl_kStatebutton->SetParamIndex(kStatebutton);
		ctl_kStatebutton->SetImageId(IMG_StateButton);
		Add(ctl_kStatebutton);

		HSwitch *ctl_kHSwitch = new HSwitch();
		ctl_kHSwitch->SetSize(132, 20);
		ctl_kHSwitch->SetLocation(36, 51);
		ctl_kHSwitch->SetParamIndex(kHSwitch);
		ctl_kHSwitch->SetImageId(IMG_HSwitch);
		ctl_kHSwitch->SetMin(0);
		ctl_kHSwitch->SetMax(2);
		ctl_kHSwitch->SetOptionsCount(3);
		Add(ctl_kHSwitch);


    }    
	virtual void OnLoad();
	virtual void OnUpdate(int index, double value);
};
#endif

