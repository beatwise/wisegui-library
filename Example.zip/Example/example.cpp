/*
  WiseGui Library's usage example

  file: example.cpp

  Copyright (c) 2013, Alessandro De Santis
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the author nor the names of its contributors may 
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <windows.h>

#include "config.h"
#include "example.h"

#include "MainView.h"
#include "OtherView.h"

extern void Terminate();

Example::Example(audioMasterCallback audioMaster) 
	: AudioEffectX(audioMaster, PROGRAMS_COUNT, kParamsCount)
{
	Setup();

    if (audioMaster) 
	{
		isSynth(true);
		setNumInputs(INPUTS_COUNT);
        setNumOutputs(OUTPUTS_COUNT);
        setUniqueID(VST_ID);
        canProcessReplacing();

		View *view = new MainView(this);
		_gui = new Gui(this, GUI_WIDTH, GUI_HEIGHT);
		_gui->SetView(view);
		setEditor(_gui);
    }
}

Example::~Example() 
{
	Terminate();
}

VstInt32 Example::canDo (char* text)
{
	if (!strcmp(text, "receiveVstEvents"))
		return 1;
	if (!strcmp(text, "receiveVstMidiEvent"))
		return 1;
	if (!strcmp (text, "midiProgramNames"))
		return 1;
	return -1;
}

//----------------------------------------------------------
// PROGRAMS MANAGEMENT

bool Example::getProgramNameIndexed(
	VstInt32 category, VstInt32 index, char* text)
{	
	_snprintf(text, 16, "prg %d", index);
	return true;
}

void Example::getProgramName(char *name) 
{
	_snprintf(name, 16, "prg %d", curProgram);
}


void Example::setProgram(VstInt32 program) 
{
	if (program < PROGRAMS_COUNT)
	{
		// set the parameters to default values
		for (int i = 0; i < kParamsCount; i++)			
			_programs[program][i].Init();

		curProgram = program;	

		// update all the controls' values
		if (_gui != NULL)
			_gui->RequestViewUpdate();
	}
}

VstInt32 Example::getProgram() 
{
	return curProgram;
}


//----------------------------------------------------------
// AUDIO

void Example::process(float **inputs, float **outputs, long frames)
{
    processReplacing(inputs, outputs, frames);
}

void Example::processReplacing(float **inputs, float **outputs, VstInt32 frames)
{
    float *outl = outputs[0];
    float *outr = outputs[1];
	memset(outl, 0, frames * sizeof(float));
	memset(outr, 0, frames * sizeof(float));
}

//----------------------------------------------------------
// PARAMETERS DEFINITIONS

void Example::getParameterLabel(VstInt32 index, char* label)
{
	strncpy(label, _programs[curProgram][index].GetLabel().c_str(), 
		kVstMaxParamStrLen);
}

void Example::getParameterDisplay(VstInt32 index, char* text)
{
	_snprintf(text, kVstMaxParamStrLen - 1, "%f", 
		_programs[curProgram][index].GetValue());	
}

void Example::getParameterName(VstInt32 index, char* text)
{
	strncpy(text, _programs[curProgram][index].GetName().c_str(), 
		kVstMaxParamStrLen);
}

bool Example::getParameterProperties(VstInt32 index, VstParameterProperties* p) 
{
	if (index >= kParamsCount)
		return false;

	p->flags = kVstParameterSupportsDisplayIndex;
	p->displayIndex = index;	
	p->minInteger = (VstInt32)_programs[curProgram][index].GetMin();
	p->maxInteger = (VstInt32)_programs[curProgram][index].GetMax();

	if (_programs[curProgram][index].GetType() == CTYPE_DOUBLE)
	{
		p->flags |= kVstParameterUsesFloatStep;
		p->stepFloat = 1;
		p->largeStepFloat = 1;
	}
	else if (_programs[curProgram][index].GetType() == CTYPE_BOOL)
	{
		p->flags |= (kVstParameterIsSwitch 
			| kVstParameterUsesIntStep);
		p->stepInteger = 1;
		p->largeStepInteger = 1;
	}
	else if (_programs[curProgram][index].GetType() == CTYPE_INT)
	{
		p->flags |= kVstParameterUsesFloatStep;
		p->stepFloat = 1;
		p->largeStepFloat = 1;
		//p->flags |= kVstParameterUsesIntStep; 
		//p->stepInteger = 1;
		//p->largeStepInteger = 1;
	}

	return true; 
}

//----------------------------------------------------------
// PARAMETERS MANAGEMENT

void Example::setParameter(VstInt32 index, float value)
{
	if (index < 0 || index >= kParamsCount)
		return;

	_programs[curProgram][index].SetNormalValue(value);

	if (_gui)
	{
		// update the control's value
		_gui->RequestControlUpdate(index, value);
	}
}

float Example::getParameter(VstInt32 index)
{
	if (0 <= index && index < kParamsCount)
		return _programs[curProgram][index].GetNormalValue();
	return 0.f;
}

//----------------------------------------------------------
// WISEGUI STUFF

// The user has changed some control's value
void Example::ParamChanged(int index, double value)
{
	if (index < 0)
		return;

	if (index < kParamsCount)
		// notify the host
		setParameterAutomated(index, (float)value);
	else
	{
		// preview some controls
		if (index == kButton)
		{
			View *view = new OtherView(this);
			_gui->SetView(view);		
		}
		else if (index == kButton1)
		{
			View *view = new MainView(this);
			_gui->SetView(view);		
		}
		else
			// notify the gui (a non "hosted" parameter)
			_gui->GetView()->OnUpdate(index, value);			
	}
}

// The gui asks for a normalized parameter's value 
double Example::GetParamValue(int index, bool normal)
{
	if (! (0 <= index && index < kParamsCount) )
		return 0.f;

	if (normal)
		return _programs[curProgram][index].GetNormalValue();
	
	return _programs[curProgram][index].GetValue();
}

// The gui asks for a parameter's info
ParamInfo *Example::GetParamInfo(int index)
{
	if (0 <= index && index < kParamsCount)
		return &_programs[curProgram][index];

	return NULL;
}


//----------------------------------------------------------
// SETUP PROGRAMS & PARAMETERS VALUES

void Example::Setup()
{
	// params are inserted in the order in which they 	
	// are defined in ids.h
	int i = 0;

	// Program 1
	_programs[i].push_back(P0(-50));
	_programs[i].push_back(P1(0));
	_programs[i].push_back(P2(-25));
	_programs[i].push_back(P3(0));
	_programs[i].push_back(P4(0));
	_programs[i].push_back(P5(0));
	_programs[i].push_back(P6(0));
	_programs[i].push_back(P7(0));
	_programs[i].push_back(P8(-1));
	_programs[i].push_back(P9(-0.5));
	_programs[i].push_back(P10(-10));
	_programs[i].push_back(P11(-0.5));
	_programs[i].push_back(P12(-10));
	_programs[i].push_back(P13(-1));

	i++;

	// Program 2
	_programs[i].push_back(P0(0));
	_programs[i].push_back(P1(1));
	_programs[i].push_back(P2(0));
	_programs[i].push_back(P3(0));
	_programs[i].push_back(P4(4));
	_programs[i].push_back(P5(25));
	_programs[i].push_back(P6(0));
	_programs[i].push_back(P7(1));
	_programs[i].push_back(P8(0));
	_programs[i].push_back(P9(0));
	_programs[i].push_back(P10(0));
	_programs[i].push_back(P11(0));
	_programs[i].push_back(P12(0));
	_programs[i].push_back(P13(0));

	i++;

	// Program 3
	_programs[i].push_back(P0(50));
	_programs[i].push_back(P1(2));
	_programs[i].push_back(P2(25));
	_programs[i].push_back(P3(1));
	_programs[i].push_back(P4(7));
	_programs[i].push_back(P5(50));
	_programs[i].push_back(P6(1));
	_programs[i].push_back(P7(2));
	_programs[i].push_back(P8(1));
	_programs[i].push_back(P9(0.5));
	_programs[i].push_back(P10(10));
	_programs[i].push_back(P11(0.5));
	_programs[i].push_back(P12(10));
	_programs[i].push_back(P13(1));
}

