/*
  WiseGui Library's usage example

  file: example.h

  Copyright (c) 2013, Alessandro De Santis
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the author nor the names of its contributors may 
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef __EXAMPLE_
#define __EXAMPLE_

#include "vstsdk/audioeffectx.h"
#include "config.h"
#include "gui.h"

#include <stdio.h>
#include <vector>
using namespace std;

#include "wisegui.h"

class Example 
	: public AudioEffectX, public ControlListener
{
    public:
        Example(audioMasterCallback audioMaster);
        ~Example();

		VstInt32 canDo(char* text);

        void process(float **inputs, float **outputs, long frames);
        void processReplacing(float **inputs, float **outputs, VstInt32 frames);
		
		bool getEffectName(char* name) 
			{ _snprintf(name, 31, EFFECT_NAME); return true; }
		virtual VstInt32 getVendorVersion() 
			{ return VENDOR_VERSION; }
		bool getVendorString(char *txt) 
			{strcpy(txt, VENDOR_STRING); return true;}
		bool getProductString(char *txt) 
			{strcpy(txt, PRODUCT_STRING); return true;}

		void Setup();
		bool getProgramNameIndexed(VstInt32 category, VstInt32 index, char* text);
		void getProgramName(char *name);
		void setProgramName(char *name){}
		VstInt32 getProgram();
		void setProgram(VstInt32 program);

		void setParameter (VstInt32 index, float value);
		float getParameter (VstInt32 index);

		void getParameterLabel (VstInt32 index, char* label);
		void getParameterDisplay (VstInt32 index, char* text);
		void getParameterName (VstInt32 index, char* text);
		bool getParameterProperties(VstInt32 index, VstParameterProperties* p);

		// WiseGui's ControlListener
		void ParamChanged(int, double);
		double GetParamValue(int index, bool normal = true);
		ParamInfo *GetParamInfo(int index);

		vector<ParamInfo> _programs[PROGRAMS_COUNT];
		Gui *_gui;
};

#endif // __EXAMPLE_


