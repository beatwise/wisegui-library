/*
  WiseGui Library's usage example

  file: OtherView.cpp

  Copyright (c) 2013, Alessandro De Santis
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the author nor the names of its contributors may 
      be used to endorse or promote products derived from this software 
      without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

// AUTO GENERATED CODE
#include "OtherView.h"

// Called when the Gui is opened/initialized
void OtherView::OnLoad() 
{
	char text[64];
	ControlListener *cl = GetListener();

	_snprintf(text, 63, "%3.2f", cl->GetParamValue(kVSlider1, false));
	SetControlValue(kLabel1, (int)text);

	_snprintf(text, 63, "%3.2f", cl->GetParamValue(kVSlider2, false));
	SetControlValue(kLabel2, (int)text);

	_snprintf(text, 63, "%3.2f", cl->GetParamValue(kVSlider3, false));
	SetControlValue(kLabel3, (int)text);

	_snprintf(text, 63, "%3.2f", cl->GetParamValue(kKnob1, false));
	SetControlValue(kLabel4, (int)text);

	_snprintf(text, 63, "%3.2f", cl->GetParamValue(kKnob2, false));
	SetControlValue(kLabel5, (int)text);

	_snprintf(text, 63, "%3.2f", cl->GetParamValue(kKnob3, false));
	SetControlValue(kLabel6, (int)text);
}

// Called when a control's value needs to be updated
void OtherView::OnUpdate(int index, double value) 
{
	char text[64];
	_snprintf(text, 63, "%3.2f", GetListener()->GetParamValue(index, false));

	if (index == kVSlider1)
		SetControlValue(kLabel1, (int)text);
	else if (index == kVSlider2)
		SetControlValue(kLabel2, (int)text);
	else if (index == kVSlider3)
		SetControlValue(kLabel3, (int)text);
	else if (index == kKnob1)
		SetControlValue(kLabel4, (int)text);
	else if (index == kKnob2)
		SetControlValue(kLabel5, (int)text);
	else if (index == kKnob3)
		SetControlValue(kLabel6, (int)text);
}

