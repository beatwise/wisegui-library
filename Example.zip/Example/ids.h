#define kKnob 0
#define kVSwitch 1
#define kVSlider 2
#define kCheckbox 3
#define kDropdownlist 4
#define kHSlider 5
#define kStatebutton 6
#define kHSwitch 7
#define kVSlider1 8
#define kVSlider2 9
#define kVSlider3 10
#define kKnob2 11
#define kKnob3 12
#define kKnob1 13
#define PARAMS_COUNT 14
#define kButton 1024
#define kLabel 1025
#define kButton1 1026
#define kLabel1 1027
#define kLabel2 1028
#define kLabel3 1029
#define kLabel4 1030
#define kLabel5 1031
#define kLabel6 1032

#define P0(v) ParamInfo(kKnob, CTYPE_DOUBLE, -50, 50, v, "knob", "")
#define P1(v) ParamInfo(kVSwitch, CTYPE_INT, 0, 2, v, "vswitch", "")
#define P2(v) ParamInfo(kVSlider, CTYPE_DOUBLE, -25, 25, v, "vslider", "")
#define P3(v) ParamInfo(kCheckbox, CTYPE_BOOL, 0, 1, v, "checkbox", "")
#define P4(v) ParamInfo(kDropdownlist, CTYPE_INT, 0, 7, v, "ddlist", "")
#define P5(v) ParamInfo(kHSlider, CTYPE_DOUBLE, 0, 50, v, "hslider", "")
#define P6(v) ParamInfo(kStatebutton, CTYPE_BOOL, 0, 1, v, "statebutton", "")
#define P7(v) ParamInfo(kHSwitch, CTYPE_INT, 0, 2, v, "hswitch", "")
#define P8(v) ParamInfo(kVSlider1, CTYPE_DOUBLE, -1, 1, v, "vslider1", "")
#define P9(v) ParamInfo(kVSlider2, CTYPE_DOUBLE, -0.5, 0.5, v, "vslider2", "")
#define P10(v) ParamInfo(kVSlider3, CTYPE_DOUBLE, -10, 10, v, "vslider3", "")
#define P11(v) ParamInfo(kKnob2, CTYPE_DOUBLE, -0.5, 0.5, v, "knob2", "")
#define P12(v) ParamInfo(kKnob3, CTYPE_DOUBLE, -10, 10, v, "knob3", "")
#define P13(v) ParamInfo(kKnob1, CTYPE_DOUBLE, -1, 1, v, "knob1", "")
