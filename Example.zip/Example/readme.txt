
  Compiling:
  ---------------------------

  1.  Compile the Wisegui library.
  2.  Copy WiseGuiLibrary.lib and wisegui.h to the example's main folder
      and rename WiseGuiLibrary.lib to wisegui.lib
  3.  Copy all the wisegui's header files to the example's wisegui folder.

  4.  Get the VSTSDK 2.4 from Steinberg.
  5.  Copy the following files to the example's vstsdk folder:
	aeffect.h 
	aeffectx.h 
	aeffeditor.h 
	audioeffect.cpp
	audioeffect.h 
	audioeffectx.cpp 
	audioeffectx.h

  6.  Open "Visual Studio Command Prompt".
  7.  Go to the example's root folder.
  8.  Run nmake.
  9.  The Dll will be placed in the bin folder.



